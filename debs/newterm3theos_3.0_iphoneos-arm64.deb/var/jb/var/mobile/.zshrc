export THEOS=~/theos
#language
LANG=zh_CN.UTF-8
LANGUAGE=zh_CN.UTF-8